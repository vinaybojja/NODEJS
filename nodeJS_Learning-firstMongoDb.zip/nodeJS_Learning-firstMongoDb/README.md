# nodeJS_Learning

task:

5. MongoDB and its connection with Nodejs
6. Express App
