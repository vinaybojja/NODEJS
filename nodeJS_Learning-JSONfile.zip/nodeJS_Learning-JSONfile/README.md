# nodeJS_Learning

task:

6. Express App
8. Handling JSON data. 
